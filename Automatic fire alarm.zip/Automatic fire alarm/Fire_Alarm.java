import java.util.Random;

public class Fire_Alarm {

	public static void main(String[] args) {
		String [] state= {"Normal","smokeing","fire"};
		String[] action= {"alarm"};
		Random random=new Random();
		for(int i=0;i<10;i++) {
			String randomState=state[random.nextInt(state.length)];
			switch(randomState) {
			case "Normal":
				System.out.println("State: "+state[0]+" =>Action: "+action[0]);
				break;
			case "smokeing":
				System.out.println("State: "+state[1]+" =>Action: "+action[0]);
				break;
			case "fire":
				System.out.println("State: "+state[2]+" =>Action: "+action[0]);
				break;
				default:
					System.out.println(" Failed");
					
			}
			

		}
		
	}

}