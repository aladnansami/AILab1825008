
import math
import random
import time 
doorClosed  = True 
doorOpen = False


def DoorOpen(interrupt=False):
    doorOpen = True
    doorClosed = False
    print("Door Opened")
    if (interrupt == True): 
        print("Human Interruption Found")
        time.sleep(random.randint(10,50))
    else:
        time.sleep(10)
    
    print("Door Closed")
    doorOpen = False
    doorClosed = True
    
    
    

def DoorClosed(): 
    print("Door Closed")
    doorClosed = True
    doorOpen = False
    

for i in range(1,10):
    
    weight_sense = random.randint(50,600)  #limit: 500kg
    senseHuman = random.choice([True, False])
    
    currentstate = random.randint(1,10)
    destination = random.randint(1,10)
    
    if (weight_sense > 500):
        DoorClosed();
        print("WARNING: OVERWEIGHT; WEIGHT LIMIT: 500KG")

    else:
        pass

    if (senseHuman == True):
        if (doorOpen == True):
            DoorOpen(interrupt = True)  # interrupt the door being closed
        else: 
            DoorClosed()

    else:
        pass

    if (currentstate == destination):
        DoorOpen()
    else:
        DoorClosed()
    i= i+ 1