
package AILABEXAM;

import java.util.Scanner;
public class automaticDoor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("-----------------------------------------------------");
        System.out.println("Rules");
        System.out.println("1. Door Always on Closed Mode");
        System.out.println("2. Agent comes on door front: Door become open.");
        System.out.println("3. Agent comes on door backend: Door become open.");
        System.out.println("4. Nothing on front of door and backend of the door: Door closed.");
        System.out.println("-----------------------------------------------------");
        System.out.println("Automatic Door Program start.....");
        System.out.println("Door Closed.");
        System.out.println("Anyone come in front of the door.");
        String agent = sc.nextLine();
        
        if(agent.equals("yes")){
            System.out.println("Door opening.....");
            System.out.println("Welcome to the room.");
        }else{
            System.out.println("No one is in front of the door. Door Closed");
        }
        System.out.println("");
        System.out.println("Anyone come in backend of the door.");
        String agent2 = sc.nextLine(); 
        if(agent2.equals("yes")){
            System.out.println("Door Opening..........");
            System.out.println("Thank You! Come again...");
        }else{
            System.out.println("Door always on clsoed mode.");
        }
        System.out.println("");
    }
   
}
